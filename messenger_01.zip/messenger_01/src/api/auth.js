import axios from "axios";

export const registerUser = (formData) =>
  axios.post("http://localhost:5000/api/auth/register", formData, {
    headers: { "Content-Type": "multipart/form-data" },
  });

export const loginUser = (data) =>
  axios.post("http://localhost:5000/api/auth/login", data);
