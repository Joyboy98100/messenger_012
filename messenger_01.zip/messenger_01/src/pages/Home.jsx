import React, { useState, useEffect } from "react";
import ChatItem from "../components/chat/ChatItem";
import SidebarIcons from "../components/layout/SidebarIcons";
import MessageBubble from "../components/chat/MessageBubble";
import MessageInput from "../components/chat/MessageInput";
import Avatar from "../components/common/Avatar";
import ProfilePanel from "../components/profile/ProfilePanel";
import SettingsPanel from "../components/settings/SettingsPanel";
import UsersPanel from "../components/users/UsersPanel";
import RequestsPanel from "../components/notifications/RequestsPanel";

import socket from "../socket";
import { saveMessage, getMessages } from "../api/messages";
import { getFriends } from "../api/friends";

const Home = () => {
  const [activeChat, setActiveChat] = useState(null);
  const [friends, setFriends] = useState([]);
  const [search, setSearch] = useState("");
  const [activePanel, setActivePanel] = useState(null);
  const [messages, setMessages] = useState({});
  const [typingUser, setTypingUser] = useState(null);
  const [onlineUsers, setOnlineUsers] = useState([]);

  /* LOAD FRIENDS */
  useEffect(() => {
    const loadFriends = async () => {
      try {
        const res = await getFriends();
        setFriends(res.data);
        if (res.data.length > 0) setActiveChat(res.data[0]);
      } catch (err) {
        console.log(err);
      }
    };
    loadFriends();
  }, []);

  /* JOIN SOCKET */
  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("user"));
    if (user) socket.emit("join", user._id);
  }, []);

  /* RECEIVE MESSAGE */
  useEffect(() => {
    socket.on("receiveMessage", ({ senderId, message }) => {
      const user = JSON.parse(localStorage.getItem("user"));

      setMessages((prev) => ({
        ...prev,
        [senderId]: [
          ...(prev[senderId] || []),
          {
            text: message,
            isOwn: false,
            time: new Date().toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            }),
          },
        ],
      }));

      socket.emit("messageDelivered", {
        senderId,
        receiverId: user.id,
      });
    });

    return () => socket.off("receiveMessage");
  }, []);

  /* LOAD CHAT HISTORY */
  useEffect(() => {
    const fetchMessages = async () => {
      const user = JSON.parse(localStorage.getItem("user"));
      if (!user || !activeChat) return;

      try {
        const res = await getMessages(user.id, activeChat._id);

        const formatted = res.data.map((m) => ({
          text: m.translatedText || m.text,
          isOwn: m.sender === user.id,
          time: new Date(m.createdAt).toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
          }),
          status: m.status || "seen",
        }));

        setMessages((prev) => ({
          ...prev,
          [activeChat._id]: formatted,
        }));
      } catch (err) {
        console.log(err);
      }
    };

    fetchMessages();

    const user = JSON.parse(localStorage.getItem("user"));
    if (user && activeChat) {
      socket.emit("messageSeen", {
        senderId: activeChat._id,
        receiverId: user.id,
      });
    }
  }, [activeChat]);

  /* TYPING LISTEN */
  useEffect(() => {
    socket.on("userTyping", (senderId) => {
      if (senderId === activeChat?._id) setTypingUser(senderId);
    });

    socket.on("userStopTyping", (senderId) => {
      if (senderId === activeChat?._id) setTypingUser(null);
    });

    return () => {
      socket.off("userTyping");
      socket.off("userStopTyping");
    };
  }, [activeChat]);

  /* ONLINE USERS */
  useEffect(() => {
    socket.on("onlineUsers", (users) => setOnlineUsers(users));
    return () => socket.off("onlineUsers");
  }, []);

  /* SEND MESSAGE */
  const handleSendMessage = async (msg) => {
    const user = JSON.parse(localStorage.getItem("user"));
    if (!activeChat) return;

    const newMessage = {
      text: msg,
      isOwn: true,
      status: "sent",
      time: new Date().toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      }),
    };

    setMessages((prev) => ({
      ...prev,
      [activeChat._id]: [...(prev[activeChat._id] || []), newMessage],
    }));

    try {
      await saveMessage({
        sender: user.id,
        receiver: activeChat._id,
        text: msg,
      });
    } catch (err) {
      console.log(err);
    }

    socket.emit("sendMessage", {
      senderId: user.id,
      receiverId: activeChat._id,
      message: msg,
    });
  };

  /* FILE DROP */
  const handleDrop = (e) => {
    e.preventDefault();
    if (!activeChat) return;

    const file = e.dataTransfer.files[0];
    if (!file) return;

    const fileURL = URL.createObjectURL(file);

    const newMessage = {
      type: file.type.startsWith("image")
        ? "image"
        : file.type.startsWith("video")
        ? "video"
        : "file",
      file: fileURL,
      isOwn: true,
      time: new Date().toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      }),
    };

    setMessages((prev) => ({
      ...prev,
      [activeChat._id]: [...(prev[activeChat._id] || []), newMessage],
    }));
  };

  return (
    <div className="h-screen w-full bg-[#eef1f7] flex items-center justify-center">
      <div className="w-[95%] h-[92%] bg-white rounded-3xl shadow-lg flex overflow-hidden">

        <SidebarIcons
          onProfileClick={() =>
            setActivePanel(activePanel === "profile" ? null : "profile")
          }
          onSettingsClick={() =>
            setActivePanel(activePanel === "settings" ? null : "settings")
          }
          onUsersClick={() =>
            setActivePanel(activePanel === "users" ? null : "users")
          }
          onRequestsClick={() =>
            setActivePanel(activePanel === "requests" ? null : "requests")
          }
        />

        {/* FRIEND LIST */}
        <div className="w-[300px] border-r bg-white flex flex-col">
          <div className="p-4">
            <input
              type="text"
              placeholder="Search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full p-2 rounded-lg bg-gray-100 outline-none"
            />
          </div>

          <div className="px-4 pb-2 text-sm font-semibold">Friends</div>

          <div className="flex-1 overflow-y-auto mt-2">
            {friends
              .filter((f) =>
                f.username.toLowerCase().includes(search.toLowerCase())
              )
              .map((friend) => (
                <div key={friend._id} onClick={() => setActiveChat(friend)}>
                  <ChatItem
                    name={friend.username}
                    message="Start chatting..."
                    time=""
                    online={onlineUsers.includes(String(friend._id))}
                    active={activeChat?._id === friend._id}
                  />
                </div>
              ))}
          </div>
        </div>

        {/* CHAT AREA */}
        <div
          className="flex-1 bg-[#f7f8fc] flex flex-col p-6"
          onDragOver={(e) => e.preventDefault()}
          onDrop={handleDrop}
        >
          {activeChat && (
            <>
              <div className="flex items-center justify-between bg-white p-4 rounded-xl shadow-sm">
                <div className="flex items-center gap-3">
                  <Avatar
                    name={activeChat.username}
                    src={activeChat.avatar}
                    size="md"
                    online={onlineUsers.includes(String(activeChat._id))}
                  />
                  <div>
                    <h3 className="font-semibold">{activeChat.username}</h3>
                    <p className="text-xs">
                      {typingUser ? (
                        <span className="text-purple-500 animate-pulse">
                          Typing...
                        </span>
                      ) : onlineUsers.includes(String(activeChat._id)) ? (
                        <span className="text-green-500">Online</span>
                      ) : (
                        <span className="text-gray-400">Offline</span>
                      )}
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto py-6 space-y-4">
                {messages[activeChat._id]?.map((msg, index) => (
                  <MessageBubble key={index} {...msg} />
                ))}
              </div>

              <MessageInput onSend={handleSendMessage} />
            </>
          )}
        </div>

        {/* RIGHT PANEL */}
        <div
          className={`transition-all duration-300 ease-in-out ${
            activePanel ? "w-[340px]" : "w-0"
          } overflow-hidden`}
        >
          {activePanel === "profile" && (
            <ProfilePanel onClose={() => setActivePanel(null)} />
          )}
          {activePanel === "settings" && (
            <SettingsPanel onClose={() => setActivePanel(null)} />
          )}
          {activePanel === "users" && (
            <UsersPanel onClose={() => setActivePanel(null)} />
          )}
          {activePanel === "requests" && (
            <RequestsPanel onClose={() => setActivePanel(null)} />
          )}
        </div>

      </div>
    </div>
  );
};

export default Home;
