import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { loginUser, registerUser } from "../api/auth";
import { useEffect } from "react";


const Auth = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [avatarPreview, setAvatarPreview] = useState(null);
  const [avatarFile, setAvatarFile] = useState(null);

  const [emailOrUsername, setEmailOrUsername] = useState("");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [bio, setBio] = useState("");

  const navigate = useNavigate();

  /* HANDLE AVATAR */
  const handleAvatarChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setAvatarFile(file);
      setAvatarPreview(URL.createObjectURL(file));
    }
  };

  useEffect(() => {
  const token = localStorage.getItem("token");
  if (token) navigate("/home");
}, []);


  /* SUBMIT */
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      if (isLogin) {
        const res = await loginUser({
          emailOrUsername,
          password,
        });

        localStorage.setItem("token", res.data.token);
        localStorage.setItem("user", JSON.stringify(res.data.user));

        navigate("/home");
      } else {
        const formData = new FormData();

        formData.append("username", username);
        formData.append("email", email);
        formData.append("password", password);
        formData.append("bio", bio);
        formData.append("preferredLanguage", "English");

        if (avatarFile) {
          formData.append("avatar", avatarFile);
        }

        await registerUser(formData);

        alert("Registered successfully. Please login.");
        setIsLogin(true);
      }
    } catch (err) {
      alert(err.response?.data?.message || "Something went wrong");
    }
  };

  useEffect(() => {
  const token = localStorage.getItem("token");
  if (token) {
    navigate("/home");
  }
}, []);


  return (
    <div className="relative h-screen w-full overflow-hidden">
      {/* Background Video */}
      <video
        autoPlay
        loop
        muted
        playsInline
        className="absolute top-0 left-0 w-full h-full object-cover"
      >
        <source src="/bg.mp4" type="video/mp4" />
      </video>

      {/* Overlay */}
      <div className="absolute w-full h-full bg-black/40"></div>

      {/* Auth Box */}
      <div className="relative z-10 flex items-center justify-center h-full">
        <div className="backdrop-blur-lg bg-white/20 border border-white/30 shadow-xl p-10 rounded-3xl w-[400px]">

          <h1 className="text-3xl font-bold text-white text-center mb-2">
            {isLogin ? "Welcome Back" : "Create Account"}
          </h1>

          <p className="text-center text-white/80 mb-6">
            {isLogin ? "Login to continue" : "Join the messenger 🚀"}
          </p>

          <form onSubmit={handleSubmit} className="flex flex-col gap-4 items-center">

            {/* Avatar Upload */}
            {!isLogin && (
              <div className="flex flex-col items-center mb-2">
                <label className="cursor-pointer">
                  <div className="w-24 h-24 rounded-full bg-white/70 flex items-center justify-center overflow-hidden border-2 border-white">
                    {avatarPreview ? (
                      <img
                        src={avatarPreview}
                        alt="avatar"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <span className="text-gray-700 text-sm">Upload</span>
                    )}
                  </div>

                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleAvatarChange}
                    className="hidden"
                  />
                </label>
              </div>
            )}

            {/* Login */}
            {isLogin && (
              <input
                type="text"
                placeholder="Email or Username"
                value={emailOrUsername}
                onChange={(e) => setEmailOrUsername(e.target.value)}
                className="p-3 rounded-xl bg-white/80 outline-none w-full"
              />
            )}

            {/* Register */}
            {!isLogin && (
              <>
                <input
                  type="text"
                  placeholder="Username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="p-3 rounded-xl bg-white/80 outline-none w-full"
                />

                <input
                  type="email"
                  placeholder="Email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="p-3 rounded-xl bg-white/80 outline-none w-full"
                />
              </>
            )}

            {/* Password */}
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="p-3 rounded-xl bg-white/80 outline-none w-full"
            />

            {/* Bio */}
            {!isLogin && (
              <textarea
                placeholder="Bio"
                rows="2"
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className="p-3 rounded-xl bg-white/80 outline-none resize-none w-full"
              />
            )}

            <button
              type="submit"
              className="bg-purple-600 hover:bg-purple-700 text-white p-3 rounded-xl font-semibold transition mt-2 w-full"
            >
              {isLogin ? "Login" : "Register"}
            </button>
          </form>

          {/* Toggle */}
          <p className="text-center text-white mt-6 text-sm">
            {isLogin ? "Don’t have an account?" : "Already have an account?"}{" "}
            <span
              onClick={() => setIsLogin(!isLogin)}
              className="font-semibold underline cursor-pointer"
            >
              {isLogin ? "Register" : "Login"}
            </span>
          </p>

        </div>
      </div>
    </div>
  );
};

export default Auth;
