import React, { useEffect, useState } from "react";
import Avatar from "../common/Avatar";
import { updateProfile } from "../../api/user";

const ProfilePanel = ({ onClose }) => {
  const [user, setUser] = useState(null);
  const [editing, setEditing] = useState(false);
  const [avatarFile, setAvatarFile] = useState(null);
  const [avatarPreview, setAvatarPreview] = useState(null);

  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem("user"));
    if (storedUser) {
      setUser(storedUser);
      setAvatarPreview(storedUser.avatar);
    }
  }, []);

  if (!user) return null;

  const handleAvatarChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setAvatarFile(file);
      setAvatarPreview(URL.createObjectURL(file));
    }
  };

  const handleSave = async () => {
    try {
      const formData = new FormData();
      formData.append("id", user.id);
      formData.append("username", user.username);
      formData.append("email", user.email);
      formData.append("bio", user.bio);
      formData.append("preferredLanguage", user.preferredLanguage);

      if (avatarFile) {
        formData.append("avatar", avatarFile);
      }

      const res = await updateProfile(formData);

      localStorage.setItem("user", JSON.stringify(res.data));
      setUser(res.data);
      setEditing(false);
    } catch (err) {
      alert("Failed to update profile");
    }
  };

  return (
    <div className="w-[340px] h-full bg-[#f7f8fc] border-l p-5 flex flex-col overflow-y-auto">

      {/* Top Card */}
      <div className="bg-white rounded-2xl p-5 shadow-sm text-center relative">

        <button
          onClick={onClose}
          className="absolute top-3 right-3 text-gray-400 hover:text-black"
        >
          ✕
        </button>

        {/* EDIT BUTTON */}
        <button
          onClick={() => setEditing(!editing)}
          className="absolute top-3 left-3 text-gray-400 hover:text-black"
        >
          ✏️
        </button>

        <div className="flex justify-center">
          <label className={editing ? "cursor-pointer" : ""}>
            <Avatar
              name={user.username}
              src={avatarPreview}
              size="lg"
            />
            {editing && (
              <input
                type="file"
                accept="image/*"
                onChange={handleAvatarChange}
                className="hidden"
              />
            )}
          </label>
        </div>

        {editing ? (
          <input
            className="mt-3 border p-2 rounded w-full text-center"
            value={user.username}
            onChange={(e) =>
              setUser({ ...user, username: e.target.value })
            }
          />
        ) : (
          <h2 className="mt-3 font-semibold text-lg">{user.username}</h2>
        )}

        <p className="text-green-500 text-sm">Active</p>
      </div>

      {/* Info Section */}
      <div className="bg-white rounded-2xl p-4 shadow-sm mt-4 space-y-4">

        {/* Username */}
        <div>
          <p className="text-xs text-gray-400">Username</p>
          {editing ? (
            <input
              className="border p-2 rounded w-full"
              value={user.username}
              onChange={(e) =>
                setUser({ ...user, username: e.target.value })
              }
            />
          ) : (
            <p className="font-medium">{user.username}</p>
          )}
        </div>

        {/* Email */}
        <div>
          <p className="text-xs text-gray-400">Email</p>
          {editing ? (
            <input
              className="border p-2 rounded w-full"
              value={user.email}
              onChange={(e) =>
                setUser({ ...user, email: e.target.value })
              }
            />
          ) : (
            <p className="font-medium">{user.email}</p>
          )}
        </div>

        {/* Bio */}
        <div>
          <p className="text-xs text-gray-400">Bio</p>
          {editing ? (
            <textarea
              className="border p-2 rounded w-full"
              value={user.bio}
              onChange={(e) =>
                setUser({ ...user, bio: e.target.value })
              }
            />
          ) : (
            <p className="font-medium">{user.bio || "No bio"}</p>
          )}
        </div>

        {/* Preferred Language */}
        <div>
          <p className="text-xs text-gray-400">Preferred Language</p>
          {editing ? (
            <select
              className="border p-2 rounded w-full"
              value={user.preferredLanguage}
              onChange={(e) =>
                setUser({
                  ...user,
                  preferredLanguage: e.target.value,
                })
              }
            >
              <option>English</option>
              <option>Hindi</option>
              <option>Gujarati</option>
              <option>Marathi</option>
              <option>Bengali</option>
              <option>Odia</option>
            </select>
          ) : (
            <p className="font-medium">{user.preferredLanguage}</p>
          )}
        </div>

        {/* SAVE BUTTON */}
        {editing && (
          <button
            onClick={handleSave}
            className="bg-purple-600 text-white w-full py-2 rounded-lg"
          >
            Save Changes
          </button>
        )}
      </div>

      {/* Shared Media */}
      <div className="bg-white rounded-2xl p-4 shadow-sm mt-4 flex-1">
        <h3 className="font-semibold mb-3">Shared media</h3>

        <div className="grid grid-cols-3 gap-2">
          {[...Array(12)].map((_, i) => (
            <div key={i} className="bg-gray-200 h-16 rounded-lg"></div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProfilePanel;
