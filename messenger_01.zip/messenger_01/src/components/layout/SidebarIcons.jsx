import React, { useState } from "react";
import {
  MessageCircle,
  Users,
  Phone,
  Settings
} from "lucide-react";

const SidebarIcons = ({ onProfileClick, onSettingsClick, onUsersClick, onRequestsClick }) => {

  const [active, setActive] = useState("chats");

  const iconClass = (name) =>
    `p-2 rounded-lg transition ${active === name
      ? "bg-purple-600 text-white"
      : "text-gray-500 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-[#1e293b]"
    }`;

  return (
    <div className="w-[80px] bg-[#f6f7fb] dark:bg-[#020617] flex flex-col items-center py-6 justify-between border-r">

      {/* Top */}
      <div className="flex flex-col items-center gap-6">

        {/* Logo */}
        <div className="w-10 h-10 rounded-xl bg-purple-600 shadow-sm flex items-center justify-center">
          <span className="text-white font-bold text-2xl">T</span>
        </div>


        {/* Icons */}
        <div className="flex flex-col gap-6 mt-6">

          <button
            title="Chats"
            onClick={() => setActive("chats")}
            className={iconClass("chats")}
          >
            <MessageCircle size={22} />
          </button>

          <button
            title="Contacts"
            onClick={() => setActive("contacts")}
            className={iconClass("contacts")}
          >
            <Users size={22} />
          </button>

          <button
            title="Calls"
            onClick={() => setActive("calls")}
            className={iconClass("calls")}
          >
            <Phone size={22} />
          </button>

          <button
            title="Settings"
            onClick={() => {
              setActive("settings");
              onSettingsClick();
            }}
            className={iconClass("settings")}
          >

            <Settings size={22} />
          </button>



        </div>
      </div>

            <div
  onClick={onRequestsClick}
  className="w-8 h-8 rounded-lg bg-gray-300 cursor-pointer hover:bg-gray-400 transition flex items-center justify-center"
>
  🔔
</div>

<div
  onClick={onUsersClick}
  className="w-8 h-8 rounded-lg bg-gray-300 cursor-pointer hover:bg-gray-400 transition flex items-center justify-center"
>
  👥
</div>


      {/* Profile */}
      <div
        onClick={onProfileClick}
        className="
          w-10 h-10 rounded-full bg-gray-300 cursor-pointer
          hover:scale-105 hover:bg-gray-400
          transition-all duration-200
        "
        title="Profile"
      ></div>

      


    </div>
  );
};

export default SidebarIcons;
