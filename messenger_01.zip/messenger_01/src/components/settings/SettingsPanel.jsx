import React from "react";
import { useNavigate } from "react-router-dom";


const SettingsPanel = ({ onClose }) => {

  const navigate = useNavigate();

  const handleLogout = () => {
  localStorage.removeItem("token");
  localStorage.removeItem("user");
  window.location.href = "/";
};


  return (
    <div className="w-[340px] h-full">
      <div className="w-full h-full overflow-y-auto bg-[#f7f8fc] dark:bg-[#020617] border-l p-5 flex flex-col">

        {/* Header */}
        <div className="bg-white dark:bg-[#1e293b] rounded-2xl p-5 shadow-sm relative">
          <button
            onClick={onClose}
            className="absolute top-3 right-3 text-gray-400 hover:text-black dark:hover:text-white"
          >
            ✕
          </button>

          <h2 className="text-lg font-semibold">Settings</h2>
          <p className="text-sm text-gray-400">Manage your preferences</p>
        </div>

        {/* General Settings */}
        <div className="bg-white dark:bg-[#1e293b] rounded-2xl p-4 shadow-sm mt-4 space-y-4">

          {/* Dark Mode */}
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Dark Mode</span>
            <span className="text-xs text-gray-400">Already in header</span>
          </div>

          {/* Notifications */}
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Notifications</span>
            <input type="checkbox" defaultChecked />
          </div>

          {/* Sound */}
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Message Sound</span>
            <input type="checkbox" defaultChecked />
          </div>

        </div>

        {/* Privacy */}
        <div className="bg-white dark:bg-[#1e293b] rounded-2xl p-4 shadow-sm mt-4 space-y-3">
          <h3 className="font-semibold">Privacy</h3>

          <div className="flex justify-between text-sm">
            <span>Last Seen</span>
            <span className="text-gray-400">Everyone</span>
          </div>

          <div className="flex justify-between text-sm">
            <span>Profile Photo</span>
            <span className="text-gray-400">Everyone</span>
          </div>
        </div>

        {/* Logout Section */}
        <div className="mt-4">
          <button
  onClick={handleLogout}
  className="w-full bg-red-500 hover:bg-red-600 text-white py-3 rounded-xl font-medium"
>
  Logout
</button>

        </div>

      </div>
    </div>
  );
};

export default SettingsPanel;
