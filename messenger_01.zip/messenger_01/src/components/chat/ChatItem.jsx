import React from "react";
import Avatar from "../common/Avatar";


const ChatItem = ({
  name = "User Name",
  message = "Last message preview...",
  time = "12:45",
  active = false,
  online = false,
}) => {

  return (
    <div
      className={`flex items-center gap-3 px-4 py-3 cursor-pointer transition rounded-xl mx-2
      ${active ? "bg-purple-100" : "hover:bg-gray-100"}`}
    >
      {/* Avatar */}
      <Avatar name={name} size="lg" online={online} />



      {/* Name + Message */}
      <div className="flex-1 min-w-0">
        <h4 className="font-semibold text-sm">{name}</h4>
        <p className="text-xs text-gray-500 truncate">
          {message}
        </p>
      </div>

      {/* Time */}
      <span className="text-xs text-gray-400">{time}</span>
    </div>
  );
};

export default ChatItem;
