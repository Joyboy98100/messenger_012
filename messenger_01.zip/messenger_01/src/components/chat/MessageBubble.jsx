import React from "react";

const MessageBubble = ({ text, isOwn, type = "text", file, time, status }) => {

  return (
    <div className={`flex ${isOwn ? "justify-end" : "justify-start"}`}>

      <div
        className={`
          px-4 py-2 rounded-xl shadow max-w-xs text-sm relative
          ${isOwn ? "bg-purple-600 text-white" : "bg-white dark:bg-[#1e293b] text-gray-800 dark:text-white"}
        `}
      >

        {/* TEXT */}
        {type === "text" && <p>{text}</p>}

        {/* IMAGE */}
        {type === "image" && (
          <img
            src={file}
            alt="sent"
            className="rounded-lg max-h-48 object-cover"
          />
        )}

        {/* VIDEO */}
        {type === "video" && (
          <video
            src={file}
            controls
            className="rounded-lg max-h-48"
          />
        )}

        {/* FILE */}
        {type === "file" && (
          <a
            href={file}
            className="underline"
            target="_blank"
            rel="noreferrer"
          >
            📄 Download File
          </a>
        )}

        {/* TIME */}
        {time && (
          <div
            className={`
      text-[10px] mt-1 flex items-center justify-end gap-1
      ${isOwn ? "text-white/80" : "text-gray-500 dark:text-gray-400"}
    `}
          >
            <span>{time}</span>

            {isOwn && (
              <span
                className={`
          text-xs
          ${status === "seen"
                    ? "text-blue-400"
                    : "text-white/80"
                  }
        `}
              >
                {status === "sent" && "✓"}
                {status === "delivered" && "✓✓"}
                {status === "seen" && "✓✓"}
              </span>
            )}
          </div>
        )}

      </div>
    </div>
  );
};

export default MessageBubble;
