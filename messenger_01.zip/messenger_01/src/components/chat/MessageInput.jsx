import React, { useRef, useState, useEffect } from "react";
import socket from "../../socket";


const MessageInput = ({ onSend }) => {
  const fileRef = useRef();
  const menuRef = useRef();
  const [showMenu, setShowMenu] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [message, setMessage] = useState("");

  const openFilePicker = () => {
    fileRef.current.click();
    setShowMenu(false);
  };

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (
        menuRef.current &&
        !menuRef.current.contains(e.target) &&
        !e.target.closest("button")
      ) {
        setShowMenu(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // SEND MESSAGE
  const handleSend = () => {
    if (!message.trim()) return;
    onSend(message);
    setMessage("");
  };

  // ENTER KEY SEND
  const handleKeyDown = (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleSend();
    }
  };

  const [text, setText] = useState("");


  return (
    <div className="relative bg-white dark:bg-[#1e293b] p-3 rounded-xl flex items-center gap-3 shadow-sm">

      {/* Hidden file input */}
      <input type="file" ref={fileRef} className="hidden" />

      {/* 📎 Attachment Button */}
      <button
        onClick={() => setShowMenu(!showMenu)}
        className="text-gray-500 dark:text-gray-300 text-lg"
      >
        📎
      </button>

      {/* Attachment Menu */}
      {showMenu && (
        <div
          ref={menuRef}
          className="absolute bottom-16 left-2 bg-white dark:bg-[#0f172a] shadow-xl rounded-2xl p-4 grid grid-cols-2 gap-4 w-48"
        >
          <div onClick={openFilePicker} className="flex flex-col items-center cursor-pointer">
            <div className="w-12 h-12 rounded-full bg-pink-100 flex items-center justify-center text-xl">🖼️</div>
            <span className="text-xs mt-1">Image</span>
          </div>

          <div onClick={openFilePicker} className="flex flex-col items-center cursor-pointer">
            <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center text-xl">🎥</div>
            <span className="text-xs mt-1">Video</span>
          </div>

          <div onClick={openFilePicker} className="flex flex-col items-center cursor-pointer">
            <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center text-xl">📄</div>
            <span className="text-xs mt-1">Document</span>
          </div>

          <div onClick={openFilePicker} className="flex flex-col items-center cursor-pointer">
            <div className="w-12 h-12 rounded-full bg-yellow-100 flex items-center justify-center text-xl">📷</div>
            <span className="text-xs mt-1">Camera</span>
          </div>
        </div>
      )}

      {/* 🎤 Voice Button */}
      <button
        onClick={() => setIsRecording(!isRecording)}
        className={`text-lg ${isRecording ? "text-red-500 animate-pulse" : "text-gray-500 dark:text-gray-300"}`}
      >
        🎤
      </button>

      {/* TEXT INPUT */}
      <input
  type="text"
  value={text}
  onChange={(e) => {
    setText(e.target.value);

    const user = JSON.parse(localStorage.getItem("user"));
    if (user) {
      socket.emit("typing", {
        senderId: user.id,
        receiverId: activeChatId
      });
    }
  }}
  placeholder="Write a message..."
  className="flex-1 p-2 outline-none"
/>


      {/* SEND BUTTON */}
      <button
        onClick={() => {
  onSend(text);
  setText("");

  const user = JSON.parse(localStorage.getItem("user"));
  socket.emit("stopTyping", {
    senderId: user.id,
    receiverId: activeChatId
  });
}}

        className="bg-purple-600 text-white px-4 py-2 rounded-lg"
      >
        Send
      </button>

      {/* Recording indicator */}
      {isRecording && (
        <div className="absolute -top-10 left-1/2 -translate-x-1/2 bg-red-500 text-white px-4 py-1 rounded-full text-xs animate-pulse">
          Recording...
        </div>
      )}
    </div>
  );
};

export default MessageInput;
