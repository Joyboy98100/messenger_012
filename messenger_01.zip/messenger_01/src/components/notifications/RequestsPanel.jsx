import React, { useEffect, useState } from "react";
import Avatar from "../common/Avatar";
import {
  getIncomingRequests,
  acceptRequest,
  rejectRequest
} from "../../api/friends";

const RequestsPanel = ({ onClose }) => {
  const [requests, setRequests] = useState([]);

  useEffect(() => {
    loadRequests();
  }, []);

  const loadRequests = async () => {
    try {
      const res = await getIncomingRequests();
      setRequests(res.data);
    } catch (err) {
      console.log(err);
    }
  };

  const handleAccept = async (id) => {
    await acceptRequest(id);
    setRequests((prev) => prev.filter((r) => r._id !== id));
  };

  const handleReject = async (id) => {
    await rejectRequest(id);
    setRequests((prev) => prev.filter((r) => r._id !== id));
  };

  return (
    <div className="w-[340px] h-full">
      <div className="w-full h-full overflow-y-auto bg-[#f7f8fc] border-l p-5 flex flex-col">

        {/* Header */}
        <div className="bg-white rounded-2xl p-5 shadow-sm relative">
          <button
            onClick={onClose}
            className="absolute top-3 right-3 text-gray-400 hover:text-black"
          >
            ✕
          </button>

          <h2 className="text-lg font-semibold">Friend Requests</h2>
          <p className="text-sm text-gray-400">
            People who want to connect
          </p>
        </div>

        {/* List */}
        <div className="mt-4 space-y-3">
          {requests.length === 0 && (
            <p className="text-center text-gray-400 text-sm">
              No pending requests
            </p>
          )}

          {requests.map((req) => (
            <div
              key={req._id}
              className="bg-white rounded-xl p-3 shadow-sm flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <Avatar
                  name={req.sender.username}
                  src={req.sender.avatar}
                  size="md"
                />
                <div>
                  <p className="font-medium text-sm">
                    {req.sender.username}
                  </p>
                  <p className="text-xs text-gray-400">
                    wants to connect
                  </p>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => handleAccept(req._id)}
                  className="bg-green-500 text-white text-xs px-3 py-1 rounded-lg"
                >
                  Accept
                </button>

                <button
                  onClick={() => handleReject(req._id)}
                  className="bg-red-500 text-white text-xs px-3 py-1 rounded-lg"
                >
                  Reject
                </button>
              </div>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
};

export default RequestsPanel;
