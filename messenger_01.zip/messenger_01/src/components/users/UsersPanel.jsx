import React, { useEffect, useState } from "react";
import Avatar from "../common/Avatar";
import { getAllUsers, sendFriendRequest } from "../../api/friends";

const UsersPanel = ({ onClose }) => {
  const [users, setUsers] = useState([]);
  const [sending, setSending] = useState(null);

  useEffect(() => {
    const loadUsers = async () => {
      try {
        const res = await getAllUsers();
        setUsers(res.data);
      } catch (err) {
        console.log(err);
      }
    };

    loadUsers();
  }, []);

  const handleSend = async (id) => {
    try {
      setSending(id);
      await sendFriendRequest(id);
      setUsers((prev) => prev.filter((u) => u._id !== id));
    } catch (err) {
      alert(err.response?.data?.message || "Failed to send request");
    } finally {
      setSending(null);
    }
  };

  return (
    <div className="w-[340px] h-full">
      <div className="w-full h-full overflow-y-auto bg-[#f7f8fc] border-l p-5 flex flex-col">

        {/* Header */}
        <div className="bg-white rounded-2xl p-5 shadow-sm relative">
          <button
            onClick={onClose}
            className="absolute top-3 right-3 text-gray-400 hover:text-black"
          >
            ✕
          </button>

          <h2 className="text-lg font-semibold">Discover People</h2>
          <p className="text-sm text-gray-400">
            Send requests to start chatting
          </p>
        </div>

        {/* Users List */}
        <div className="mt-4 space-y-3">
          {users.length === 0 && (
            <p className="text-center text-gray-400 text-sm">
              No new users found
            </p>
          )}

          {users.map((user) => (
            <div
              key={user._id}
              className="bg-white rounded-xl p-3 shadow-sm flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <Avatar name={user.username} src={user.avatar} size="md" />
                <div>
                  <p className="font-medium text-sm">{user.username}</p>
                  <p className="text-xs text-gray-400 truncate w-[120px]">
                    {user.bio || "No bio"}
                  </p>
                </div>
              </div>

              <button
                onClick={() => handleSend(user._id)}
                disabled={sending === user._id}
                className="bg-purple-600 text-white text-xs px-3 py-1 rounded-lg hover:bg-purple-700"
              >
                {sending === user._id ? "Sending..." : "Add"}
              </button>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
};

export default UsersPanel;
