import FriendRequest from "../models/FriendRequest.js";
import User from "../models/User.js";

/* SEND FRIEND REQUEST */
export const sendRequest = async (req, res) => {
  try {
    const senderId = req.user; // from JWT middleware
    const { receiverId } = req.body;

    // ❌ cannot send to self
    if (senderId === receiverId) {
      return res.status(400).json({ message: "Cannot send request to yourself" });
    }

    // ❌ check existing request
    const existing = await FriendRequest.findOne({
      sender: senderId,
      receiver: receiverId,
    });

    if (existing) {
      return res.status(400).json({ message: "Request already sent" });
    }

    // ❌ check reverse request (receiver already sent to sender)
    const reverse = await FriendRequest.findOne({
      sender: receiverId,
      receiver: senderId,
    });

    if (reverse) {
      return res.status(400).json({
        message: "User already sent you a request",
      });
    }

    // ✅ create request
    const request = await FriendRequest.create({
      sender: senderId,
      receiver: receiverId,
    });

    res.status(201).json(request);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};


/* ACCEPT FRIEND REQUEST */
export const acceptRequest = async (req, res) => {
  try {
    const userId = req.user; // logged-in user
    const { requestId } = req.body;

    const request = await FriendRequest.findById(requestId);

    if (!request)
      return res.status(404).json({ message: "Request not found" });

    // Only receiver can accept
    if (request.receiver.toString() !== userId) {
      return res.status(403).json({ message: "Not authorized" });
    }

    request.status = "accepted";
    await request.save();

    res.json({ message: "Friend request accepted", request });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

/* REJECT FRIEND REQUEST */
export const rejectRequest = async (req, res) => {
  try {
    const userId = req.user; // logged-in user
    const { requestId } = req.body;

    const request = await FriendRequest.findById(requestId);

    if (!request)
      return res.status(404).json({ message: "Request not found" });

    // Only receiver can reject
    if (request.receiver.toString() !== userId) {
      return res.status(403).json({ message: "Not authorized" });
    }

    request.status = "rejected";
    await request.save();

    res.json({ message: "Friend request rejected" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

/* GET INCOMING REQUESTS (NOTIFICATIONS) */
export const getIncomingRequests = async (req, res) => {
  try {
    const userId = req.user;

    const requests = await FriendRequest.find({
      receiver: userId,
      status: "pending",
    })
      .populate("sender", "username email avatar")
      .sort({ createdAt: -1 });

    res.json(requests);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};


/* GET FRIENDS LIST */
export const getFriendsList = async (req, res) => {
  try {
    const userId = req.user;

    const friendships = await FriendRequest.find({
      status: "accepted",
      $or: [
        { sender: userId },
        { receiver: userId }
      ]
    })
      .populate("sender", "username avatar email")
      .populate("receiver", "username avatar email");

    // Extract the OTHER person from each relation
    const friends = friendships.map((f) => {
      if (f.sender._id.toString() === userId) {
        return f.receiver;
      } else {
        return f.sender;
      }
    });

    res.json(friends);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};


/* GET ALL USERS YOU CAN SEND REQUEST TO */
export const getAllUsers = async (req, res) => {
  try {
    const userId = req.user;

    // Get all friend relations
    const relations = await FriendRequest.find({
      $or: [
        { sender: userId },
        { receiver: userId }
      ]
    });

    // Collect all related user IDs
    const excludedIds = new Set();

    relations.forEach((r) => {
      excludedIds.add(r.sender.toString());
      excludedIds.add(r.receiver.toString());
    });

    // Also exclude self
    excludedIds.add(userId);

    // Fetch users not in excluded list
    const users = await User.find({
      _id: { $nin: Array.from(excludedIds) }
    }).select("username email avatar bio");

    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

