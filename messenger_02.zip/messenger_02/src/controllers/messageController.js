import Message from "../models/Message.js";
import User from "../models/User.js";
import translate from "@vitalets/google-translate-api";
import FriendRequest from "../models/FriendRequest.js";


const langMap = {
  English: "en",
  Hindi: "hi",
  Gujarati: "gu",
  Marathi: "mr",
  Bengali: "bn",
  Odia: "or"
};


/* SAVE MESSAGE + TRANSLATE */
export const saveMessage = async (req, res) => {
  try {
    const { sender, receiver, text } = req.body;

    // find receiver preferred language
    const receiverUser = await User.findById(receiver);

    let detectedLanguage = "auto";
    let translatedText = text;

    try {
      const result = await translate(text, {
to: langMap[receiverUser.preferredLanguage] || "en"
      });

      detectedLanguage = result.from.language.iso;
      translatedText = result.text;
    } catch (err) {
      console.log("Translation error:", err.message);
    }

    const message = new Message({
      sender,
      receiver,
      text,
      detectedLanguage,
      translatedText
    });

    await message.save();

    res.status(201).json(message);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

/* GET CHAT HISTORY */
export const getMessages = async (req, res) => {
  try {
    const { user1, user2 } = req.params;

    const messages = await Message.find({
      $or: [
        { sender: user1, receiver: user2 },
        { sender: user2, receiver: user1 },
      ],
    }).sort({ createdAt: 1 });

    res.json(messages);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
