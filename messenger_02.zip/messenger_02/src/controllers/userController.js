import User from "../models/User.js";
import cloudinary from "../utils/cloudinary.js";

export const updateProfile = async (req, res) => {
  try {
    const { id, username, email, bio, preferredLanguage } = req.body;

    let avatarUrl = req.body.avatar;

    // If new avatar uploaded
    if (req.file) {
      const uploadRes = await cloudinary.uploader.upload(
        `data:${req.file.mimetype};base64,${req.file.buffer.toString("base64")}`,
        { folder: "avatars" }
      );
      avatarUrl = uploadRes.secure_url;
    }

    const updatedUser = await User.findByIdAndUpdate(
      id,
      {
        username,
        email,
        bio,
        preferredLanguage,
        avatar: avatarUrl,
      },
      { new: true }
    );

    res.json(updatedUser);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
