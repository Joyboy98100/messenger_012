import User from "../models/User.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import cloudinary from "../utils/cloudinary.js";

/* =========================
   REGISTER
========================= */
export const registerUser = async (req, res) => {
  try {
    const { username, email, password, bio, preferredLanguage } = req.body;

    console.log("BODY:", req.body);
console.log("FILE:", req.file);


    // check if user exists
    const existingUser = await User.findOne({ email });
    if (existingUser)
      return res.status(400).json({ message: "User already exists" });

    // hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    let avatarUrl = "";

    // upload avatar to Cloudinary
    if (req.file) {
      const uploadRes = await cloudinary.uploader.upload(
        `data:${req.file.mimetype};base64,${req.file.buffer.toString("base64")}`,
        { folder: "avatars" }
      );

      avatarUrl = uploadRes.secure_url;
    }

    // create user
    const user = new User({
      username,
      email,
      password: hashedPassword,
      bio,
      preferredLanguage,
      avatar: avatarUrl,
    });

    await user.save();

    res.status(201).json({
      message: "User registered successfully",
      user,
    });
  } catch (err) {
  console.log("REGISTER ERROR:", err);
  res.status(500).json({ error: err.message });
}

};

/* =========================
   LOGIN
========================= */
export const login = async (req, res) => {
  try {
    const { emailOrUsername, password } = req.body;

    // find user by email OR username
    const user = await User.findOne({
      $or: [{ email: emailOrUsername }, { username: emailOrUsername }],
    });

    if (!user)
      return res.status(400).json({ message: "User not found" });

    // compare password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch)
      return res.status(400).json({ message: "Invalid credentials" });

    // create token
    const token = jwt.sign(
      { id: user._id },
      process.env.JWT_SECRET,
      { expiresIn: "7d" }
    );

    res.json({
      token,
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        bio: user.bio,
        avatar: user.avatar,
        preferredLanguage: user.preferredLanguage,
      },
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
