import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import dotenv from "dotenv";
import { createServer } from "http";
import { Server } from "socket.io";
import messageRoutes from "./routes/messageRoutes.js";
import friendRequestRoutes from "./routes/friendRequestRoutes.js";

import authRoutes from "./routes/authRoutes.js";
import userRoutes from "./routes/userRoutes.js";



dotenv.config();

const app = express();
const httpServer = createServer(app);

const io = new Server(httpServer, {
  cors: {
    origin: "http://localhost:5173", // frontend port
    methods: ["GET", "POST"]
  }
});

app.use(cors());
app.use(express.json());

app.use("/api/auth", authRoutes);
app.use("/api/messages", messageRoutes);
app.use("/api/user", userRoutes);
app.use("/api/friends", friendRequestRoutes);


app.get("/", (req, res) => {
  res.send("API running...");
});

/* SOCKET CONNECTION */
let onlineUsers = {};

io.on("connection", (socket) => {
  console.log("User connected:", socket.id);

  socket.on("join", (userId) => {
    onlineUsers[userId] = socket.id;

    // Send updated online users to everyone
    io.emit("onlineUsers", Object.keys(onlineUsers));
  });

  socket.on("sendMessage", async ({ senderId, receiverId, message }) => {
    const receiverSocket = onlineUsers[receiverId];

    if (receiverSocket) {
      io.to(receiverSocket).emit("receiveMessage", {
        senderId,
        message,
      });
    }
  });

  socket.on("typing", ({ senderId, receiverId }) => {
    const receiverSocket = onlineUsers[receiverId];
    if (receiverSocket) {
      io.to(receiverSocket).emit("userTyping", senderId);
    }
  });

  socket.on("stopTyping", ({ senderId, receiverId }) => {
    const receiverSocket = onlineUsers[receiverId];
    if (receiverSocket) {
      io.to(receiverSocket).emit("userStopTyping", senderId);
    }
  });

  socket.on("disconnect", () => {
    // remove user from online list
    for (let userId in onlineUsers) {
      if (onlineUsers[userId] === socket.id) {
        delete onlineUsers[userId];
        break;
      }
    }

    // Delivered
socket.on("messageDelivered", ({ senderId, receiverId }) => {
  const senderSocket = onlineUsers[senderId];
  if (senderSocket) {
    io.to(senderSocket).emit("updateStatus", {
      receiverId,
      status: "delivered",
    });
  }
});

// Seen
socket.on("messageSeen", ({ senderId, receiverId }) => {
  const senderSocket = onlineUsers[senderId];
  if (senderSocket) {
    io.to(senderSocket).emit("updateStatus", {
      receiverId,
      status: "seen",
    });
  }
});


    // broadcast updated list
    io.emit("onlineUsers", Object.keys(onlineUsers));

    console.log("User disconnected:", socket.id);
  });
});


mongoose.connect(process.env.MONGO_URI)
.then(() => console.log("MongoDB Atlas connected"))
.catch(err => console.log(err));

const PORT = process.env.PORT || 5000;

httpServer.listen(PORT, () =>
  console.log(`Server running on port ${PORT}`)
);
