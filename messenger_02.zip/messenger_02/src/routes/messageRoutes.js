import express from "express";
import { saveMessage, getMessages } from "../controllers/messageController.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

/* SAVE MESSAGE */
router.post("/send", protect, saveMessage);

/* GET CHAT HISTORY */
router.get("/:user1/:user2", protect, getMessages);

export default router;
