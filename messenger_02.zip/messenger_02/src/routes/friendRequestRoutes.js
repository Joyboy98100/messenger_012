import express from "express";
import {
  sendRequest,
  acceptRequest,
  rejectRequest,
  getIncomingRequests,
  getFriendsList,
  getAllUsers
} from "../controllers/friendRequestController.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

router.post("/send", protect, sendRequest);
router.post("/accept", protect, acceptRequest);
router.post("/reject", protect, rejectRequest);
router.get("/incoming", protect, getIncomingRequests);
router.get("/friends", protect, getFriendsList);
router.get("/all-users", protect, getAllUsers);

export default router;
