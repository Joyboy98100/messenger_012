import express from "express";
import upload from "../middleware/upload.js";
import { updateProfile } from "../controllers/userController.js";

const router = express.Router();

router.put("/update", upload.single("avatar"), updateProfile);

export default router;
