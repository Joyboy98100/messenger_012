import mongoose from "mongoose";

const messageSchema = new mongoose.Schema(
  {
    sender: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
    receiver: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
    text: String,
    type: {
      type: String,
      default: "text", // text, image, video, file
    },
    file: String,
    status: {
      type: String,
      default: "sent",
    },
    detectedLanguage: String,
    translatedText: String,
  },
  { timestamps: true }
);

export default mongoose.model("Message", messageSchema);
